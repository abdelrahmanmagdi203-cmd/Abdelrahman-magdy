# Abdelrahman Magdy — Portfolio Website

A responsive, static portfolio website for GitHub and Cloudflare Pages.

## Included

- Responsive dark navy and gold visual identity
- Hero, profile, capabilities, selected work, results, process and contact sections
- Filterable project portfolio with accessible project-detail dialogs
- 14 portfolio entries, including:
  - VALER — Salla e-commerce store
  - International Team for Exhibitions & Conferences
  - AFAQ Company
  - Qitaf Motors, VIA Clinics, Taleen Medical, Elite, Emaar, Palm Hills,
    Global Brand Group, X.Link, BookGOG, campaign reporting and ad banners
- Optimized WebP project images from the supplied portfolio archive
- English and Arabic CV PDFs
- SEO metadata, Open Graph tags, Person structured data and favicon
- No build step, package manager or Node.js required

## Run locally

Open `index.html` in a browser. For a local web server, use Python:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish with GitHub + Cloudflare Pages

1. Create a new GitHub repository, for example `abdelrahman-portfolio`.
2. Upload the **contents** of this folder to the repository root (not the enclosing folder).
3. In Cloudflare, open **Workers & Pages → Create → Pages → Connect to Git**.
4. Select the GitHub repository and configure:
   - Production branch: `main`
   - Framework preset: `None`
   - Build command: leave empty
   - Build output directory: `.` (repository root)
5. Deploy. Cloudflare Pages will serve `index.html` directly.
6. Add a custom domain from the Pages project settings if desired.

## Update projects

Edit `projects.js`. Each project object supports:

- `id`: unique identifier
- `name`: project or brand name
- `category`: `Web & E-commerce`, `Performance Marketing`, or `Creative & Content`
- `type`, `desc`, `tag`
- `url`: live project URL (leave empty if there is no public URL)
- `cover`: use `valer`, `intteam`, or `afaq` for branded website covers
- `images`: array of local image paths for the project gallery

Add new images to `assets/` and reference them in `projects.js`.

## Contact details

- Email: Abdelrahman.magdi203@gmail.com
- Phone / WhatsApp: +966 56 753 5834
- Location: Riyadh, Saudi Arabia

## Content notes

Performance figures shown on the website are drawn from the supplied English CV:
10M+ impressions in five days, 45% increase in branch visits, 200+ qualified leads,
30% increase in direct appointment bookings, and additional campaign reach/remarketing outcomes.

The VALER website currently displays a coming-soon message. The portfolio lists it as an
e-commerce project and links to the supplied store URL; it does not claim the store is
currently open for orders.

The supplied International Team site describes a company with experience dating back to
1997. The supplied AFAQ website describes an information technology and communications
company. Project descriptions are intentionally concise and avoid adding unverified metrics.
