window.PORTFOLIO_PROJECTS = [
  {
    "id": "valer",
    "name": "VALER",
    "category": "Web & E-commerce",
    "type": "E-commerce Store",
    "desc": "A premium men’s fabrics e-commerce experience built around product discovery, refined presentation and a clear shopping journey.",
    "url": "https://valer.sa/",
    "tag": "Salla Store",
    "cover": "valer"
  },
  {
    "id": "intteam",
    "name": "International Team",
    "category": "Web & E-commerce",
    "type": "Corporate Website",
    "desc": "A corporate digital presence for an exhibitions and conferences company with a legacy dating back to 1997, operating across Saudi Arabia and Egypt.",
    "url": "https://my-website-hzpk18.webnode.page/",
    "tag": "Corporate Website",
    "cover": "intteam"
  },
  {
    "id": "afaq",
    "name": "AFAQ Company",
    "category": "Web & E-commerce",
    "type": "Technology Website",
    "desc": "A corporate website presenting information technology and communications solutions, services and selected project highlights.",
    "url": "https://afaq.webnode.page/",
    "tag": "Technology",
    "cover": "afaq"
  },
  {
    "id": "qitaf",
    "name": "Qitaf Motors",
    "category": "Performance Marketing",
    "type": "Automotive Marketing",
    "desc": "Automotive campaign creative, paid media execution and performance reporting for showroom traffic and qualified enquiries.",
    "url": "",
    "tag": "Automotive",
    "images": [
      "assets/qitaf-01.webp",
      "assets/qitaf-02.webp",
      "assets/qitaf-03.webp",
      "assets/qitaf-04.webp"
    ]
  },
  {
    "id": "via",
    "name": "VIA Clinics",
    "category": "Performance Marketing",
    "type": "Healthcare Marketing",
    "desc": "Campaign creatives and customer-journey assets for healthcare services, including lead generation and appointment-focused advertising.",
    "url": "",
    "tag": "Healthcare",
    "images": [
      "assets/via-01.webp",
      "assets/via-02.webp",
      "assets/via-03.webp"
    ]
  },
  {
    "id": "taleen",
    "name": "Taleen Medical",
    "category": "Creative & Content",
    "type": "Healthcare Creative",
    "desc": "Social media visual content and promotional creative for a medical brand.",
    "url": "",
    "tag": "Healthcare",
    "images": [
      "assets/taleen-01.webp",
      "assets/taleen-02.webp",
      "assets/taleen-03.webp",
      "assets/taleen-04.webp"
    ]
  },
  {
    "id": "elite",
    "name": "Elite",
    "category": "Creative & Content",
    "type": "Brand Campaigns",
    "desc": "A collection of visual campaign assets and promotional content for a consumer-facing brand.",
    "url": "",
    "tag": "Creative",
    "images": [
      "assets/elite-01.webp",
      "assets/elite-02.webp",
      "assets/elite-03.webp",
      "assets/elite-04.webp"
    ]
  },
  {
    "id": "emaar",
    "name": "Emaar",
    "category": "Creative & Content",
    "type": "Real Estate Marketing",
    "desc": "Marketing visuals and campaign materials for real estate communications.",
    "url": "",
    "tag": "Real Estate",
    "images": [
      "assets/emaar-01.webp",
      "assets/emaar-02.webp",
      "assets/emaar-03.webp"
    ]
  },
  {
    "id": "palmhills",
    "name": "Palm Hills",
    "category": "Creative & Content",
    "type": "Real Estate Marketing",
    "desc": "Campaign artwork and promotional content developed for real estate audiences.",
    "url": "",
    "tag": "Real Estate",
    "images": [
      "assets/palmhills-01.webp",
      "assets/palmhills-02.webp",
      "assets/palmhills-03.webp"
    ]
  },
  {
    "id": "global",
    "name": "Global Brand Group",
    "category": "Creative & Content",
    "type": "Brand Communications",
    "desc": "A set of branded promotional materials and social media campaign designs.",
    "url": "",
    "tag": "Branding",
    "images": [
      "assets/global-brand-01.webp",
      "assets/global-brand-02.webp",
      "assets/global-brand-03.webp"
    ]
  },
  {
    "id": "xlink",
    "name": "X.Link",
    "category": "Web & E-commerce",
    "type": "Digital Solutions & Brand Content",
    "desc": "A broad visual content collection presenting digital services, business technology and marketing solutions.",
    "url": "",
    "tag": "Digital Solutions",
    "images": [
      "assets/xlink-01.webp",
      "assets/xlink-02.webp",
      "assets/xlink-03.webp",
      "assets/xlink-04.webp",
      "assets/xlink-05.webp"
    ]
  },
  {
    "id": "bookgog",
    "name": "BookGOG",
    "category": "Creative & Content",
    "type": "Digital Brand Creative",
    "desc": "Brand and digital promotional creative from the supplied project archive.",
    "url": "",
    "tag": "Digital",
    "images": [
      "assets/bookgog-01.webp"
    ]
  },
  {
    "id": "campaigns",
    "name": "Paid Campaign Results",
    "category": "Performance Marketing",
    "type": "Campaign Reporting",
    "desc": "Selected campaign dashboards and reporting screenshots documenting performance monitoring and optimization work.",
    "url": "",
    "tag": "Analytics",
    "images": [
      "assets/campaign-results-01.webp",
      "assets/campaign-results-02.webp",
      "assets/campaign-results-03.webp",
      "assets/campaign-results-04.webp"
    ]
  },
  {
    "id": "banners",
    "name": "Digital Advertising Banners",
    "category": "Creative & Content",
    "type": "Ad Creative Collection",
    "desc": "A selection of digital advertising banners and campaign visuals from the project archive.",
    "url": "",
    "tag": "Ad Design",
    "images": [
      "assets/banners-01.webp",
      "assets/banners-02.webp",
      "assets/banners-03.webp",
      "assets/banners-04.webp"
    ]
  }
];
