(() => {
  const projects = window.PORTFOLIO_PROJECTS || [];
  const grid = document.getElementById('projectGrid');
  const filters = document.querySelectorAll('.filter');
  const dialog = document.getElementById('projectDialog');
  const dialogContent = document.getElementById('dialogContent');
  const closeDialog = document.querySelector('.dialog-close');

  const esc = (value='') => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const cover = (project) => {
    if (project.images && project.images.length) {
      return `<img src="${esc(project.images[0])}" alt="${esc(project.name)} project preview" loading="lazy">`;
    }
    const brandClass = ['valer','intteam','afaq'].includes(project.cover) ? project.cover : '';
    const word = project.cover === 'intteam' ? 'INTERNATIONAL<br>TEAM' : project.cover === 'afaq' ? 'AFAQ' : 'VALER';
    const sub = project.cover === 'intteam' ? 'EXHIBITIONS & CONFERENCES' : project.cover === 'afaq' ? 'TECHNOLOGY & ICT' : 'MEN’S PREMIUM FABRICS';
    return `<div class="brand-cover ${brandClass}"><strong>${word}</strong><small>${sub}</small></div>`;
  };
  function render(filter='All') {
    const selected = filter === 'All' ? projects : projects.filter(p => p.category === filter);
    grid.innerHTML = selected.map(p => `
      <article class="project-card" tabindex="0" role="button" aria-label="View ${esc(p.name)} project details" data-id="${esc(p.id)}">
        <div class="project-thumb">${cover(p)}</div>
        <div class="project-info">
          <div class="project-meta"><span>${esc(p.type)}</span><span>${esc(p.tag)}</span></div>
          <h3>${esc(p.name)}</h3>
          <p>${esc(p.desc)}</p>
          <div class="project-open">Explore project <span>↗</span></div>
        </div>
      </article>`).join('');
  }
  function openProject(id) {
    const p = projects.find(item => item.id === id);
    if (!p) return;
    const gallery = (p.images || []).slice(0,4);
    dialogContent.innerHTML = `
      <div class="section-kicker">${esc(p.category)} / ${esc(p.type)}</div>
      <h2>${esc(p.name)}</h2>
      <p>${esc(p.desc)}</p>
      ${p.url ? `<a class="dialog-link" href="${esc(p.url)}" target="_blank" rel="noopener noreferrer">Visit live website ↗</a>` : ''}
      ${gallery.length ? `<div class="dialog-gallery">${gallery.map((src,i)=>`<img src="${esc(src)}" alt="${esc(p.name)} project image ${i+1}" loading="lazy">`).join('')}</div>` : ''}
      ${!p.url && !gallery.length ? '<p>Selected project information can be shared on request.</p>' : ''}
    `;
    dialog.showModal();
  }
  filters.forEach(button => button.addEventListener('click', () => {
    filters.forEach(b => b.classList.remove('active'));
    button.classList.add('active');
    render(button.dataset.filter);
  }));
  grid.addEventListener('click', event => {
    const card = event.target.closest('.project-card');
    if (card) openProject(card.dataset.id);
  });
  grid.addEventListener('keydown', event => {
    if ((event.key === 'Enter' || event.key === ' ') && event.target.classList.contains('project-card')) {
      event.preventDefault(); openProject(event.target.dataset.id);
    }
  });
  closeDialog.addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  menuButton.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open'); menuButton.setAttribute('aria-expanded','false');
  }));
  document.getElementById('year').textContent = new Date().getFullYear();
  render();
})();